# FileMonitor
File Monitor es una plataforma colaborativa diseñada para optimizar el flujo de trabajo en la gestión, revisión y aprobación de archivos digitales. El sistema se estructura en “proyectos” y agrupa tareas, roles y funcionalidades que permiten a los usuarios manipular y administrar documentos según sus necesidades.
